%enconomic output 
function Y=output(N)

%load data
%N=15800000;%Popupation
% l=10;%length
% I=0;
global a;
global l;
global gsigma;
global gmean;

%------density------
An=arean(N);
den=N/An;
Fij=a*den/l;
%-------p(k)--------
% gk=zeros(1,150);
% pk=1/150;
% g=0;
% for i=1:1:150
%     gk(1,i)=normrnd(gmean,sigma1); 
%     g=g+gk(1,i)*pk;
% end
% g=g/150;

Y=N*gmean*Fij;



    
   




