%enconomic output 

function A=area(N)
%N=1280000;%population
global unit_cost;

%----total cost------
T=unit_cost*Length(N);
syms A
A=solve((output(N)*arean(N)/A)-T,'A');
A=vpa(A);



